from flask import Flask, render_template, request
import Banking_gui.chatgui

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("home.html")
@app.route("/get")
def get_bot_response():

    userText = request.args.get('msg')
    return str(Banking_gui.chatgui.banking_bot_response(userText))
if __name__ == "__main__":
    app.run()