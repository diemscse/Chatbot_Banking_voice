# from google_trans_new import google_translator
#
# translator = google_translator()
# translate_text = translator.translate('hello sachin', lang_tgt='hi')
# print(translate_text)
#https://github.com/lushan88a/google_trans_new

#
# from gtts import gTTS
# from audioplayer import AudioPlayer
# text="Hello dear"
# myobj = gTTS(text=text,lang='en')
# myobj.save("welcome.mp3")
# #AudioPlayer("welcome.mp3").play(block=True)
#
#
#
# import subprocess
# subprocess.call(["welcome.mp3", '--play-and-exit'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, shell=True)

#
#
# #https://chatterbot.readthedocs.io/en/stable/corpus.html
#
# from chatterbot import ChatBot
# from chatterbot.trainers import ChatterBotCorpusTrainer
#
# '''
# This is an example showing how to create an export file from
# an existing chat bot that can then be used to train other bots.
# https://chatterbot.readthedocs.io/en/stable/corpus.html
# '''
#
# chatbot = ChatBot('Export Example Bot')
#
# # First, lets train our bot with some data
# trainer = ChatterBotCorpusTrainer(chatbot)
# #trainer.train('chatterbot.corpus.english')
#
# trainer.train('chatterbot.corpus.english.greetings')
#
# # trainer.train(
# #     'chatterbot.corpus.english.greetings',
# #      'chatterbot.corpus.english.conversations'
# # )
#
# # Now we can export the data to a file
# #trainer.export_for_training('./my_export.json')
#
# print(chatbot.get_response(text="hi"))
#


# from textblob import Word
# w = Word('falibility')
# w.spellcheck()
# print(w.spellcheck())
#
# w = Word('englisgh')
# w.spellcheck()
# print(w.spellcheck())



# from textblob import TextBlob
# b = TextBlob("I havv goood speling!")
# print(b.correct())

#
# #https://pypi.org/project/language-tool-python/
#
# import language_tool_python
# tool = language_tool_python.LanguageTool('en-US')
# text = 'A sentence with a error in the Hitchhiker’s Guide tot he Galaxy'
# print(tool.correct(text))
#





#
# 'afrikaans': 'af',
# 'arabic': 'ar',
# 'belarusian': 'be',
# 'bulgarian': 'bg',
# 'catalan': 'ca',
# 'czech': 'cs',
# 'welsh': 'cy',
# 'danish': 'da',
# 'german': 'de',
# 'greek': 'el',
# 'english': 'en',
# 'esperanto': 'eo',
# 'spanish': 'es',
# 'estonian': 'et',
# 'persian': 'fa',
# 'finnish': 'fi',
# 'french': 'fr',
# 'irish': 'ga',
# 'galician': 'gl',
# 'hindi': 'hi',
# 'croatian': 'hr',
# 'hungarian': 'hu',
# 'indonesian': 'id',
# 'icelandic': 'is',
# 'italian': 'it',
# 'hebrew': 'iw',
# 'japanese': 'ja',
# 'korean': 'ko',
# 'latin': 'la',
# 'lithuanian': 'lt',
# 'latvian': 'lv',
# 'macedonian': 'mk',
# 'malay': 'ms',
# 'maltese': 'mt',
# 'dutch': 'nl',
# 'norwegian': 'no',
# 'polish': 'pl',
# 'portuguese': 'pt',
# 'romanian': 'ro',
# 'russian': 'ru',
# 'slovak': 'sk',
# 'slovenian': 'sl',
# 'albanian': 'sq',
# 'serbian': 'sr',
# 'swedish': 'sv',
# 'swahili': 'sw',
# 'thai': 'th',
# 'filipino': 'tl',
# 'turkish': 'tr',
# 'ukrainian': 'uk',
# 'vietnamese': 'vi',
# 'yiddish': 'yi',
# 'chinese_simplified': 'zh-CN',
# 'chinese_traditional': 'zh-TW',
# 'auto': 'auto'

#
#
#
# import json
# import pandas as pd
# from google_trans_new import google_translator
# translator = google_translator()
# with open(r"C:\Users\sachi\Downloads\Compressed\banking-faq-bot-master\bank_faqs.json",encoding="utf8") as f:
#     data = json.load(f)
#
# data = data['bank']
# bank_faq = pd.DataFrame(columns=['Question', 'Answer', 'Class'])
#
#
#
# for key in data.keys():
#     f = open(key+".yml", "a")
#     f.write("categories:"+"\n")
#     f.write("- "+key+"\n")
#     f.write("conversations:")
#     for qnas in data[key]:
#         f.write("\n"+"- - " + (qnas[0].replace(':', '')).replace('-', ''))
#         f.write("\n"+"  - " + (qnas[1].replace(':', '')).replace('-', ''))
#     f.close()
#
# print("done")
import pyttsx3

# import pyttsx3
# a = pyttsx3.init()
# #If this doesn't work try "languages".
# a.setProperty("language",'hi')
# a.say("नमस्ते")
# a.runAndWait()

