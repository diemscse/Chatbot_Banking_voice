import speech_recognition
from gtts import gTTS
from audioplayer import AudioPlayer
from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer
from google_trans_new import google_translator
import json
import pandas as pd

lan=input(''' type  en or hi
'english'as 'en',
'hindi' as 'hi' :  ''')

translator = google_translator()
detector = google_translator()

class VoiceChatBot(ChatBot):
    def speak(self, text):

        obj_ = gTTS(text=text,lang=lan)
        obj_.save("welcome.mp3")
        AudioPlayer("welcome.mp3").play(block=True)

    def get_response(self, statement=None, **kwargs):
        response = super().get_response(statement, **kwargs)
        print("Bot : " + translator.translate(response.text, lang_tgt=lan))
        self.speak(response.text)

bot = VoiceChatBot('Banking ChatBot')
trainer = ChatterBotCorpusTrainer(bot)
trainer.train("chatterbot.corpus.hindi.greetings"
   )

recognizer = speech_recognition.Recognizer()
print("Bot : " + translator.translate('Say Sameything', lang_tgt=lan))


while True:
    try:
        with speech_recognition.Microphone() as source:
            recognizer.adjust_for_ambient_noise(source)
            audio = recognizer.listen(source)
            recognizer_function = getattr(recognizer, 'recognize_google')
            result = recognizer_function(audio)
            print( "You : " + translator.translate(result, lang_tgt=lan))
            bot.get_response(text=translator.translate(result, lang_tgt=lan))

    except speech_recognition.UnknownValueError:
        tr="try again, Say samething"
        bot.speak(translator.translate(tr, lang_tgt=lan))
        print("Bot : " + translator.translate(tr, lang_tgt=lan))

    except (KeyboardInterrupt, EOFError, SystemExit):
        # Press ctrl-c or ctrl-d on the keyboard to exit
        break


