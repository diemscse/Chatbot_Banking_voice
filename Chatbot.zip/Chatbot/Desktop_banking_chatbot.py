import threading
from tkinter import *

import pyttsx3 as pp
import speech_recognition as s
from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer
from google_trans_new import google_translator

engine = pp.init()
translator = google_translator()
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0].id)


def speak(words):
    engine.say(words)
    engine.runAndWait()


bot = ChatBot("Banking Bot")
trainer = ListTrainer(bot)
trainer.train(r"C:\Users\sachi\Downloads\Compressed\Chatbot\hindi\loans_hn.yml"
              )



main = Tk()
main.geometry("300x450")
main.title("Banking Bot MITWPU DSA")


def take_input():
    sr = s.Recognizer()
    sr.pause_threshold = 1
    print("Bot : listening...")
    with s.Microphone() as m:
        try:
            audio = sr.listen(m)
            query = sr.recognize_google(audio, language='eng-in')
            print("You : "+query)
            text_box_input.insert(0, query)
            print("Bot : waiting checking on your question ....." )
            text_box_input.insert(1, "Bot : waiting checking on your question .....")
            sending_query()
            text_box_input.delete(0, END)
        except Exception as e:
            print(e)
            print("Bot : not recognized")


def sending_query():
    query = text_box_input.get()
    text_box_input.delete(0, END)
    input_msgs.insert(END, "You : " + query)
    response_from_banking_bot = bot.get_response(query)
    print("Bot: "+str(response_from_banking_bot))
    input_msgs.insert(END, "Bot:  : " + str(response_from_banking_bot))
    speak(response_from_banking_bot)
    text_box_input.delete(0, END)
    input_msgs.yview(END)


frame = Frame(main)
scrollbar_frame = Scrollbar(frame)
input_msgs = Listbox(frame, width=80, height=20, yscrollcommand=scrollbar_frame.set)

scrollbar_frame.pack(side=RIGHT, fill=Y)
input_msgs.pack(side=LEFT, fill=BOTH, pady=10)
frame.pack()

# creating text field
text_box_input = Entry(main, font=("Courier", 10))
text_box_input.pack(fill=X, pady=10)

#Button
btn_click = Button(main, text="Send", font=(
    "Courier", 10),bg='green', command=sending_query)
btn_click.pack()


# creating a function
def enter_function_input_by_clicking(event):
    btn_click.invoke()

main.bind('<Return>', enter_function_input_by_clicking)

def repeatL():
    while True:
        take_input()

thread_ = threading.Thread(target=repeatL)
thread_.start()

main.mainloop()


#pyinstaller --onefile -w Desktop_banking_chatbot.py